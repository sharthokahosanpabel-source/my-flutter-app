import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  double starting = 5000;
  double current = 5000;
  int step = 0;
  int totalStep = 30;
  int wins = 0;
  int losses = 0;

  double get target => starting * 1108;
  double get nextStake => current * 0.019;
  double get expected => nextStake * 3;

  void win() {
    setState(() {
      wins++;
      step++;
      current += expected;
    });
  }

  void loss() {
    setState(() {
      losses++;
      step++;
      current -= nextStake;
    });
  }

  void reset() {
    setState(() {
      current = starting;
      step = 0;
      wins = 0;
      losses = 0;
    });
  }

  Widget card(String title, String value, Color color) {
    return Container(
      padding: const EdgeInsets.all(12),
      margin: const EdgeInsets.all(6),
      decoration: BoxDecoration(
        color: Colors.purple.shade900,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        children: [
          Text(title, style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 5),
          Text(value,
              style: TextStyle(
                  color: color, fontSize: 18, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text("Money Management"),
        backgroundColor: Colors.black,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Expanded(child: card("STARTING", "৳$starting", Colors.white)),
                Expanded(
                    child: card("CURRENT", "৳${current.toStringAsFixed(0)}",
                        Colors.green)),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Expanded(
                    child: card("STEP", "$step / $totalStep", Colors.white)),
                Expanded(
                    child: card("TARGET", "৳${target.toStringAsFixed(0)}",
                        Colors.blue)),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Expanded(child: card("WINS", "$wins", Colors.green)),
                Expanded(child: card("LOSSES", "$losses", Colors.red)),
                Expanded(
                    child: card("NEXT STAKE",
                        "৳${nextStake.toStringAsFixed(2)}", Colors.orange)),
              ],
            ),
            const SizedBox(height: 10),
            Container(
              padding: const EdgeInsets.all(15),
              margin: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.black,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.white24),
              ),
              child: Column(
                children: [
                  const Text("EXPECTED RETURN (IF WIN)",
                      style: TextStyle(color: Colors.white70)),
                  Text("+৳${expected.toStringAsFixed(2)}",
                      style:
                          const TextStyle(color: Colors.green, fontSize: 20)),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Text(
                "Cycle Progress: ${((step / totalStep) * 100).toStringAsFixed(0)}%",
                style: const TextStyle(color: Colors.white)),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: win,
                  style:
                      ElevatedButton.styleFrom(backgroundColor: Colors.green),
                  child: const Text("WIN"),
                ),
                ElevatedButton(
                  onPressed: loss,
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                  child: const Text("LOSS"),
                ),
                IconButton(
                  onPressed: reset,
                  icon: const Icon(Icons.refresh, color: Colors.white),
                )
              ],
            )
          ],
        ),
      ),
    );
  }
}
